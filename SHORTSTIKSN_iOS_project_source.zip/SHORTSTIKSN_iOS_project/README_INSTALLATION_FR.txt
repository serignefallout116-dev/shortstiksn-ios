SHORTSTIKSN — PROJET SOURCE iOS (BASE DE DÉMONSTRATION)

CE QUI EST FOURNI
- Le prototype web SHORTSTIKSN existant, intégré dans www/.
- La configuration Capacitor pour générer un projet iOS natif.
- L'identifiant d'application : com.shortstiksn.app.

IMPORTANT : CE N'EST PAS UN FICHIER IPA.
Ce dossier est le projet source préparé pour une compilation iOS. Il ne contient pas encore le projet Xcode généré, la signature Apple, ni un IPA installable.

PRÉREQUIS
- Un Mac compatible avec une version récente de Xcode.
- Xcode installé depuis Apple.
- Node.js et npm.
- Un identifiant Apple. Pour distribuer largement et utiliser TestFlight/App Store, un abonnement Apple Developer est normalement nécessaire.

ÉTAPES SUR UN MAC
1. Décompresser le ZIP.
2. Ouvrir Terminal dans le dossier SHORTSTIKSN_iOS_project.
3. Exécuter : npm install
4. Exécuter : npx cap add ios
5. Exécuter : npx cap sync ios
6. Exécuter : npx cap open ios
7. Dans Xcode, sélectionner la cible SHORTSTIKSN > Signing & Capabilities.
8. Choisir une équipe de signature Apple valide et vérifier l'identifiant com.shortstiksn.app.
9. Connecter l'iPhone, le sélectionner comme appareil de destination, puis lancer Run pour un test direct.
10. Pour produire une archive/IPA, utiliser Product > Archive, puis suivre le flux de distribution/signature proposé par Xcode.

SCARLET
Scarlet est un installateur tiers : il ne compile pas le projet et ne crée pas de signature Apple valide. Un IPA doit être correctement signé pour être installé. Les certificats de signature tiers peuvent être révoqués ; ne partage jamais tes identifiants Apple ni tes certificats privés.

LIMITES DU PROTOTYPE ACTUEL
Cette version est une démonstration d'interface, pas encore un réseau social mondial opérationnel. Les vidéos importées restent locales à l'appareil/session. Il n'y a pas encore de serveur, authentification réelle, base de données, stockage vidéo distant, recommandations, vrais commentaires, messagerie, lives, notifications push ou modération en production.

PROCHAINE ÉTAPE TECHNIQUE
Après génération et test de l'app iOS, construire le backend sécurisé et les fonctions sociales avant toute ouverture au public. Ne pas lancer publiquement une plateforme vidéo sans modération, signalement, protection des mineurs, règles de confidentialité et gestion des droits sur les contenus.
